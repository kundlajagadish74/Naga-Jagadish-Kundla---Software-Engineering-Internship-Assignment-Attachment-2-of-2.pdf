package com.example.flutflix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
